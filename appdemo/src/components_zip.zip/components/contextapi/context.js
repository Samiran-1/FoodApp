import { createContext } from "react";

var myContext = new createContext();
export default myContext; //all are export in the parent