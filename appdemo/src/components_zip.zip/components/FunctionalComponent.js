import React from 'react'

function FunctionalComponent() {
  return (
    <div>
      <h2>FUNTIONAL COMPONENT</h2>
      <p>HELLO HERE I AM CREATING REACT PROJECT</p>
      <button>CLICKED</button>
    </div>
  )
}

export default FunctionalComponent
