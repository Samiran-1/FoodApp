import React from 'react'

function D({data}) {
  return (
    <div>
      <h2>D COMPONENT</h2>
      <p>{data}</p>
    </div>
  )
}

export default D
