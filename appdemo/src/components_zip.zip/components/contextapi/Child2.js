import React from 'react'
import Child3 from './Child3'
function Child2() {
  return (
    <div>
        <h2>CHILD-2 COMPONENT</h2>
      <Child3/>
    </div>
  )
}

export default Child2
