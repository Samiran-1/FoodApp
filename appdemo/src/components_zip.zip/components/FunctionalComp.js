import React from 'react'

function FunctionalComp() {
  return (
    <div>
      <h2>FUNCTIONAL ELEMENT</h2>
      <p>yeeyysysysysyysysysy</p>
      <button>CLICKED</button>
    </div>
  )
}

export default FunctionalComp
