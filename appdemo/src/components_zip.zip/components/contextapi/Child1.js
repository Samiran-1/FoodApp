import React from 'react'
import Child2 from './Child2'
function Child1() {
  return (
    <div>
        <h2>CHILD-1 COMPONENT</h2>
      <Child2/>
    </div>
  )
}

export default Child1
